<?php
namespace Ktpl\S3\Model\MediaStorage\File;

use Magento\MediaStorage\Model\File\Storage as FileStorage;

/**
 * @inheritdoc
 */
class Storage extends FileStorage
{
    const STORAGE_MEDIA_S3 = 2;
}
